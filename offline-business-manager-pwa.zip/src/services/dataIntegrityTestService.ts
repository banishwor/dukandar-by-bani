import { db } from '../db/database';
import { purchaseService } from './purchaseService';
import { purchaseCorrectionService } from './purchaseCorrectionService';
import { supplierPaymentService } from './supplierPaymentService';
import { inventoryRepository } from '../repositories/inventoryRepository';
import { roundCurrency } from '../utils/money';
import { generateUniqueId } from '../utils/id';

export interface TestResult {
  id: number;
  name: string;
  category: string;
  passed: boolean;
  message: string;
  durationMs: number;
  details?: string[];
}

export const runDataIntegrityTestSuite = async (businessId: string): Promise<TestResult[]> => {
  const results: TestResult[] = [];
  const testPrefix = `TST_${Date.now()}`;

  // Helper to create a clean test item
  const createTestItem = async (name: string, openingStock: number, unitCost: number, track = true) => {
    const itemId = generateUniqueId('ITEM');
    const now = new Date().toISOString();
    await db.items.add({
      id: itemId,
      businessId,
      name: `${testPrefix}_${name}`,
      type: 'PRODUCT',
      unit: 'pcs',
      sellingPrice: unitCost * 1.5,
      purchasePrice: unitCost,
      openingStock,
      trackInventory: track,
      isActive: true,
      createdAt: now,
      updatedAt: now,
      createdByDeviceId: 'test-device',
      updatedByDeviceId: 'test-device',
      version: 1,
      isDeleted: false,
    });
    if (track && openingStock > 0) {
      await db.stockMovements.add({
        id: generateUniqueId('STK'),
        businessId,
        itemId,
        type: 'OPENING_STOCK',
        quantityChange: openingStock,
        createdAt: now,
        createdByDeviceId: 'test-device',
        version: 1,
      });
    }
    return itemId;
  };

  // Helper to create a clean test supplier
  const createTestSupplier = async (name: string) => {
    const supplierId = generateUniqueId('SUP');
    const now = new Date().toISOString();
    await db.suppliers.add({
      id: supplierId,
      businessId,
      name: `${testPrefix}_${name}`,
      phone: '9999999999',
      isActive: true,
      createdAt: now,
      updatedAt: now,
      createdByDeviceId: 'test-device',
      updatedByDeviceId: 'test-device',
      version: 1,
      isDeleted: false,
    });
    return supplierId;
  };

  // Helper to execute and record
  const runTest = async (
    id: number,
    name: string,
    category: string,
    testFn: () => Promise<{ passed: boolean; message: string; details?: string[] }>
  ) => {
    const start = performance.now();
    try {
      const res = await testFn();
      results.push({
        id,
        name,
        category,
        passed: res.passed,
        message: res.message,
        durationMs: Math.round(performance.now() - start),
        details: res.details,
      });
    } catch (err: any) {
      results.push({
        id,
        name,
        category,
        passed: false,
        message: `Exception: ${err.message || String(err)}`,
        durationMs: Math.round(performance.now() - start),
      });
    }
  };

  // ----------------------------------------------------
  // SCENARIO 1: Simple Purchase with Full Cash Payment
  // ----------------------------------------------------
  await runTest(
    1,
    'Simple Purchase with Full Direct Payment',
    'Purchases & Inventory',
    async () => {
      const supplierId = await createTestSupplier('DirectPaySup');
      const itemId = await createTestItem('Item1', 10, 100);

      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'DirectPaySup',
        purchaseDate: new Date().toISOString(),
        lines: [
          {
            itemId,
            itemNameSnapshot: 'Item1',
            quantity: 5,
            unit: 'pcs',
            unitCost: 100,
            discountAmount: 0,
            taxAmount: 0,
            trackInventory: true,
          },
        ],
        subtotal: 500,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 500,
        paidAmount: 500,
        paymentMethod: 'CASH',
      });

      const stock = await inventoryRepository.getItemCurrentStock(itemId);
      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);

      const passed =
        purchase.status === 'PAID' &&
        purchase.dueAmount === 0 &&
        purchase.paidAmount === 500 &&
        stock === 15 &&
        summary.outstandingPayable === 0 &&
        summary.netPayable === 0;

      return {
        passed,
        message: passed
          ? 'Stock increased from 10 to 15, purchase marked PAID, and supplier payable is ₹0.'
          : `Mismatch: stock=${stock}, status=${purchase.status}, due=${purchase.dueAmount}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 2: Credit Purchase (Unpaid)
  // ----------------------------------------------------
  await runTest(
    2,
    'Credit Purchase (Unpaid Bill)',
    'Payables & Debt',
    async () => {
      const supplierId = await createTestSupplier('CreditSup');
      const itemId = await createTestItem('Item2', 0, 200);

      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'CreditSup',
        purchaseDate: new Date().toISOString(),
        lines: [
          {
            itemId,
            itemNameSnapshot: 'Item2',
            quantity: 10,
            unit: 'pcs',
            unitCost: 200,
            discountAmount: 0,
            taxAmount: 0,
            trackInventory: true,
          },
        ],
        subtotal: 2000,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 2000,
        paidAmount: 0,
        paymentMethod: 'CASH',
      });

      const stock = await inventoryRepository.getItemCurrentStock(itemId);
      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);

      const passed =
        purchase.status === 'UNPAID' &&
        purchase.dueAmount === 2000 &&
        stock === 10 &&
        summary.outstandingPayable === 2000 &&
        summary.netPayable === 2000;

      return {
        passed,
        message: passed
          ? 'Stock increased to 10 and net payable accurately derived as ₹2,000.'
          : `Mismatch: stock=${stock}, status=${purchase.status}, payable=${summary.netPayable}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 3: Partial Payment at Time of Purchase
  // ----------------------------------------------------
  await runTest(
    3,
    'Partial Payment at Bill Creation',
    'Purchases & Payments',
    async () => {
      const supplierId = await createTestSupplier('PartialSup');
      const itemId = await createTestItem('Item3', 5, 150);

      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'PartialSup',
        purchaseDate: new Date().toISOString(),
        lines: [
          {
            itemId,
            itemNameSnapshot: 'Item3',
            quantity: 4,
            unit: 'pcs',
            unitCost: 150,
            discountAmount: 0,
            taxAmount: 0,
            trackInventory: true,
          },
        ],
        subtotal: 600,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 600,
        paidAmount: 250,
        paymentMethod: 'UPI',
      });

      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);
      const passed =
        purchase.status === 'PARTIAL' &&
        purchase.paidAmount === 250 &&
        purchase.dueAmount === 350 &&
        summary.outstandingPayable === 350 &&
        summary.netPayable === 350;

      return {
        passed,
        message: passed
          ? 'Purchase status is PARTIAL, paidAmount is ₹250, and dueAmount is ₹350.'
          : `Mismatch: status=${purchase.status}, due=${purchase.dueAmount}, payable=${summary.netPayable}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 4: Subsequent FIFO Payment Allocation
  // ----------------------------------------------------
  await runTest(
    4,
    'Subsequent FIFO Payment Allocation Across Multiple Bills',
    'FIFO Engine',
    async () => {
      const supplierId = await createTestSupplier('FIFOSup');
      const itemId = await createTestItem('Item4', 0, 100);

      // Bill 1: 500 unpaid
      const pur1 = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'FIFOSup',
        purchaseDate: '2026-01-01T10:00:00Z',
        lines: [
          {
            itemId,
            itemNameSnapshot: 'Item4',
            quantity: 5,
            unit: 'pcs',
            unitCost: 100,
            discountAmount: 0,
            taxAmount: 0,
            trackInventory: true,
          },
        ],
        subtotal: 500,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 500,
        paidAmount: 0,
        paymentMethod: 'CASH',
      });

      // Bill 2: 700 unpaid
      const pur2 = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'FIFOSup',
        purchaseDate: '2026-01-02T10:00:00Z',
        lines: [
          {
            itemId,
            itemNameSnapshot: 'Item4',
            quantity: 7,
            unit: 'pcs',
            unitCost: 100,
            discountAmount: 0,
            taxAmount: 0,
            trackInventory: true,
          },
        ],
        subtotal: 700,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 700,
        paidAmount: 0,
        paymentMethod: 'CASH',
      });

      // Pay ₹800 in AUTO (FIFO) mode: should clear Bill 1 (₹500) and pay ₹300 on Bill 2
      await supplierPaymentService.recordSupplierPayment({
        businessId,
        supplierId,
        amount: 800,
        paymentMethod: 'BANK_TRANSFER',
        allocationMode: 'AUTO',
      });

      const updatedPur1 = await db.purchases.get(pur1.id);
      const updatedPur2 = await db.purchases.get(pur2.id);
      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);

      const passed =
        updatedPur1?.status === 'PAID' &&
        updatedPur1?.dueAmount === 0 &&
        updatedPur2?.status === 'PARTIAL' &&
        updatedPur2?.dueAmount === 400 &&
        summary.netPayable === 400;

      return {
        passed,
        message: passed
          ? 'FIFO engine successfully paid off Bill 1 (₹500) and partially paid Bill 2 (₹300/₹700).'
          : `Mismatch: Bill1 status=${updatedPur1?.status}, Bill2 due=${updatedPur2?.dueAmount}, netPayable=${summary.netPayable}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 5: Manual Payment Allocation
  // ----------------------------------------------------
  await runTest(
    5,
    'Targeted Manual Payment Allocation to Specific Bill',
    'Payment Allocation',
    async () => {
      const supplierId = await createTestSupplier('ManualSup');
      const itemId = await createTestItem('Item5', 0, 100);

      const pur1 = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'ManualSup',
        purchaseDate: '2026-01-01T10:00:00Z',
        lines: [{ itemId, itemNameSnapshot: 'Item5', quantity: 3, unit: 'pcs', unitCost: 100, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 300,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 300,
        paidAmount: 0,
        paymentMethod: 'CASH',
      });

      const pur2 = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'ManualSup',
        purchaseDate: '2026-01-02T10:00:00Z',
        lines: [{ itemId, itemNameSnapshot: 'Item5', quantity: 5, unit: 'pcs', unitCost: 100, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 500,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 500,
        paidAmount: 0,
        paymentMethod: 'CASH',
      });

      // Target only Bill 2 with ₹500
      await supplierPaymentService.recordSupplierPayment({
        businessId,
        supplierId,
        amount: 500,
        paymentMethod: 'CARD',
        allocationMode: 'MANUAL',
        manualAllocations: [{ purchaseId: pur2.id, amount: 500 }],
      });

      const updatedPur1 = await db.purchases.get(pur1.id);
      const updatedPur2 = await db.purchases.get(pur2.id);

      const passed =
        updatedPur1?.status === 'UNPAID' &&
        updatedPur1?.dueAmount === 300 &&
        updatedPur2?.status === 'PAID' &&
        updatedPur2?.dueAmount === 0;

      return {
        passed,
        message: passed
          ? 'Manual allocation paid Bill 2 directly without affecting earlier Bill 1.'
          : `Mismatch: Bill1=${updatedPur1?.status}, Bill2=${updatedPur2?.status}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 6: Advance Payment / Overpayment (Supplier Credit)
  // ----------------------------------------------------
  await runTest(
    6,
    'Advance Payment (Supplier Credit Generation)',
    'Supplier Credit',
    async () => {
      const supplierId = await createTestSupplier('AdvanceSup');

      // Pay ₹1,000 with 0 bills existing
      const res = await supplierPaymentService.recordSupplierPayment({
        businessId,
        supplierId,
        amount: 1000,
        paymentMethod: 'BANK_TRANSFER',
        allocationMode: 'AUTO',
      });

      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);
      const passed =
        res.unallocatedCredit === 1000 &&
        summary.supplierCredit === 1000 &&
        summary.netPayable === -1000;

      return {
        passed,
        message: passed
          ? 'Advance payment created ₹1,000 unallocated supplier credit (netPayable = -₹1,000).'
          : `Mismatch: unallocated=${res.unallocatedCredit}, supplierCredit=${summary.supplierCredit}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 7: Applying Supplier Credit to New Purchase
  // ----------------------------------------------------
  await runTest(
    7,
    'Applying Supplier Credit to New Purchase',
    'Supplier Credit',
    async () => {
      const supplierId = await createTestSupplier('ApplyCreditSup');
      const itemId = await createTestItem('Item7', 0, 100);

      // Advance payment ₹500
      await supplierPaymentService.recordSupplierPayment({
        businessId,
        supplierId,
        amount: 500,
        paymentMethod: 'CASH',
        allocationMode: 'AUTO',
      });

      // New purchase of ₹800: apply ₹500 credit + ₹300 direct cash
      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'ApplyCreditSup',
        purchaseDate: new Date().toISOString(),
        lines: [{ itemId, itemNameSnapshot: 'Item7', quantity: 8, unit: 'pcs', unitCost: 100, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 800,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 800,
        paidAmount: 300,
        paymentMethod: 'CASH',
        applySupplierCredit: 500,
      });

      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);
      const passed =
        purchase.status === 'PAID' &&
        purchase.paidAmount === 800 &&
        purchase.dueAmount === 0 &&
        summary.supplierCredit === 0 &&
        summary.netPayable === 0;

      return {
        passed,
        message: passed
          ? 'Successfully consumed ₹500 supplier credit + ₹300 cash to pay ₹800 bill in full.'
          : `Mismatch: status=${purchase.status}, paid=${purchase.paidAmount}, creditRemaining=${summary.supplierCredit}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 8: Partial Purchase Return on Unpaid Bill (Reduce Due)
  // ----------------------------------------------------
  await runTest(
    8,
    'Partial Purchase Return on Unpaid Bill (Reduce Due Mode)',
    'Purchase Returns',
    async () => {
      const supplierId = await createTestSupplier('RetReduceDueSup');
      const itemId = await createTestItem('Item8', 10, 100);

      // Buy 10 items @ ₹100 = ₹1,000 unpaid
      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'RetReduceDueSup',
        purchaseDate: new Date().toISOString(),
        lines: [{ itemId, itemNameSnapshot: 'Item8', quantity: 10, unit: 'pcs', unitCost: 100, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 1000,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 1000,
        paidAmount: 0,
        paymentMethod: 'CASH',
      });

      const lines = await db.purchaseLines.where('purchaseId').equals(purchase.id).toArray();
      const pLine = lines[0];

      // Return 3 items @ ₹100 = ₹300 with REDUCE_DUE
      await purchaseCorrectionService.processPurchaseReturn({
        businessId,
        originalPurchaseId: purchase.id,
        supplierId,
        returnDate: new Date().toISOString(),
        reason: 'DAMAGED',
        settlementMode: 'REDUCE_DUE',
        lines: [{ originalPurchaseLineId: pLine.id, quantityToReturn: 3 }],
      });

      const stock = await inventoryRepository.getItemCurrentStock(itemId);
      const updatedPurchase = await db.purchases.get(purchase.id);
      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);

      // Stock was 10 (opening) + 10 (purchase) - 3 (return) = 17
      const passed =
        stock === 17 &&
        updatedPurchase?.dueAmount === 700 &&
        summary.netPayable === 700;

      return {
        passed,
        message: passed
          ? 'Stock deducted by 3 (from 20 to 17) and purchase dueAmount reduced to ₹700.'
          : `Mismatch: stock=${stock}, dueAmount=${updatedPurchase?.dueAmount}, netPayable=${summary.netPayable}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 9: Purchase Return with Cash Refund Received
  // ----------------------------------------------------
  await runTest(
    9,
    'Purchase Return with Immediate Cash Refund Received',
    'Purchase Returns & Refunds',
    async () => {
      const supplierId = await createTestSupplier('RetRefundSup');
      const itemId = await createTestItem('Item9', 0, 100);

      // Buy 5 items @ ₹100 = ₹500 paid in full
      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'RetRefundSup',
        purchaseDate: new Date().toISOString(),
        lines: [{ itemId, itemNameSnapshot: 'Item9', quantity: 5, unit: 'pcs', unitCost: 100, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 500,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 500,
        paidAmount: 500,
        paymentMethod: 'CASH',
      });

      const lines = await db.purchaseLines.where('purchaseId').equals(purchase.id).toArray();
      const pLine = lines[0];

      // Return 2 items @ ₹100 = ₹200 with REFUND_NOW
      const retRes = await purchaseCorrectionService.processPurchaseReturn({
        businessId,
        originalPurchaseId: purchase.id,
        supplierId,
        returnDate: new Date().toISOString(),
        reason: 'DEFECTIVE',
        settlementMode: 'REFUND_NOW',
        refundPaymentMethod: 'CASH',
        lines: [{ originalPurchaseLineId: pLine.id, quantityToReturn: 2 }],
      });

      const stock = await inventoryRepository.getItemCurrentStock(itemId);
      const refunds = await db.refundsReceived.where('purchaseReturnId').equals(retRes.purchaseReturn.id).toArray();
      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);

      const passed =
        stock === 3 &&
        refunds.length === 1 &&
        refunds[0].amount === 200 &&
        summary.netPayable === 0;

      return {
        passed,
        message: passed
          ? 'Stock deducted to 3, refund received record created for ₹200, and ledger remains balanced at ₹0.'
          : `Mismatch: stock=${stock}, refundCount=${refunds.length}, netPayable=${summary.netPayable}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 10: Purchase Return with Supplier Credit
  // ----------------------------------------------------
  await runTest(
    10,
    'Purchase Return with Supplier Credit Settlement',
    'Purchase Returns & Credit',
    async () => {
      const supplierId = await createTestSupplier('RetCreditSup');
      const itemId = await createTestItem('Item10', 0, 100);

      // Buy 4 items @ ₹100 = ₹400 paid in full
      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'RetCreditSup',
        purchaseDate: new Date().toISOString(),
        lines: [{ itemId, itemNameSnapshot: 'Item10', quantity: 4, unit: 'pcs', unitCost: 100, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 400,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 400,
        paidAmount: 400,
        paymentMethod: 'CASH',
      });

      const lines = await db.purchaseLines.where('purchaseId').equals(purchase.id).toArray();
      const pLine = lines[0];

      // Return 1 item @ ₹100 = ₹100 with SUPPLIER_CREDIT
      await purchaseCorrectionService.processPurchaseReturn({
        businessId,
        originalPurchaseId: purchase.id,
        supplierId,
        returnDate: new Date().toISOString(),
        reason: 'WRONG_ITEM',
        settlementMode: 'SUPPLIER_CREDIT',
        lines: [{ originalPurchaseLineId: pLine.id, quantityToReturn: 1 }],
      });

      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);
      const passed = summary.supplierCredit === 100 && summary.netPayable === -100;

      return {
        passed,
        message: passed
          ? 'Return converted to ₹100 supplier credit for future purchases.'
          : `Mismatch: credit=${summary.supplierCredit}, netPayable=${summary.netPayable}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 11: Full Purchase Void (Unpaid Purchase)
  // ----------------------------------------------------
  await runTest(
    11,
    'Full Void of Unpaid Purchase Bill',
    'Purchase Voids',
    async () => {
      const supplierId = await createTestSupplier('VoidUnpaidSup');
      const itemId = await createTestItem('Item11', 5, 100);

      // Buy 5 items @ ₹100 = ₹500 unpaid
      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'VoidUnpaidSup',
        purchaseDate: new Date().toISOString(),
        lines: [{ itemId, itemNameSnapshot: 'Item11', quantity: 5, unit: 'pcs', unitCost: 100, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 500,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 500,
        paidAmount: 0,
        paymentMethod: 'CASH',
      });

      // Void bill
      await purchaseCorrectionService.processPurchaseVoid({
        businessId,
        originalPurchaseId: purchase.id,
        supplierId,
        reason: 'Duplicate bill entered by mistake',
        settlementMode: 'NO_SETTLEMENT',
      });

      const stock = await inventoryRepository.getItemCurrentStock(itemId);
      const updatedPurchase = await db.purchases.get(purchase.id);
      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);

      const passed =
        stock === 5 &&
        updatedPurchase?.status === 'VOIDED' &&
        updatedPurchase?.dueAmount === 0 &&
        summary.netPayable === 0;

      return {
        passed,
        message: passed
          ? 'Bill marked VOIDED, stock reverted to 5, and supplier debt removed completely.'
          : `Mismatch: stock=${stock}, status=${updatedPurchase?.status}, netPayable=${summary.netPayable}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 12: Purchase Void with Cash Refund
  // ----------------------------------------------------
  await runTest(
    12,
    'Purchase Void on Paid Bill with Cash Refund',
    'Purchase Voids & Refunds',
    async () => {
      const supplierId = await createTestSupplier('VoidPaidSup');
      const itemId = await createTestItem('Item12', 0, 150);

      // Buy 2 items @ ₹150 = ₹300 paid
      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'VoidPaidSup',
        purchaseDate: new Date().toISOString(),
        lines: [{ itemId, itemNameSnapshot: 'Item12', quantity: 2, unit: 'pcs', unitCost: 150, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 300,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 300,
        paidAmount: 300,
        paymentMethod: 'CASH',
      });

      // Void with REFUND_NOW
      const voidRes = await purchaseCorrectionService.processPurchaseVoid({
        businessId,
        originalPurchaseId: purchase.id,
        supplierId,
        reason: 'Order cancelled before dispatch',
        settlementMode: 'REFUND_NOW',
        refundPaymentMethod: 'CASH',
      });

      const stock = await inventoryRepository.getItemCurrentStock(itemId);
      const refunds = await db.refundsReceived.where('purchaseVoidId').equals(voidRes.purchaseVoid.id).toArray();
      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);

      const passed =
        stock === 0 &&
        refunds.length === 1 &&
        refunds[0].amount === 300 &&
        summary.netPayable === 0;

      return {
        passed,
        message: passed
          ? 'Stock returned to 0, refund event logged for ₹300, and financial summary balanced at ₹0.'
          : `Mismatch: stock=${stock}, refunds=${refunds.length}, netPayable=${summary.netPayable}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 13: Supplier Payment Reversal
  // ----------------------------------------------------
  await runTest(
    13,
    'Supplier Payment Reversal (Unwinds Allocations & Restores Bill Due)',
    'Payment Reversals',
    async () => {
      const supplierId = await createTestSupplier('RevPaySup');
      const itemId = await createTestItem('Item13', 0, 100);

      // Buy ₹500 unpaid
      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'RevPaySup',
        purchaseDate: new Date().toISOString(),
        lines: [{ itemId, itemNameSnapshot: 'Item13', quantity: 5, unit: 'pcs', unitCost: 100, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 500,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 500,
        paidAmount: 0,
        paymentMethod: 'CASH',
      });

      // Record ₹500 payment
      const pmtRes = await supplierPaymentService.recordSupplierPayment({
        businessId,
        supplierId,
        amount: 500,
        paymentMethod: 'BANK_TRANSFER',
        allocationMode: 'AUTO',
      });

      // Verify bill was paid
      let purCheck = await db.purchases.get(purchase.id);
      if (purCheck?.status !== 'PAID') {
        return { passed: false, message: 'Initial payment failed to mark bill as PAID' };
      }

      // Reverse payment
      await purchaseCorrectionService.processSupplierPaymentReversal({
        businessId,
        originalPaymentId: pmtRes.payment.id,
        supplierId,
        reason: 'Cheque bounced / payment failed at bank',
      });

      const finalPur = await db.purchases.get(purchase.id);
      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);

      const passed =
        finalPur?.status === 'UNPAID' &&
        finalPur?.dueAmount === 500 &&
        summary.outstandingPayable === 500 &&
        summary.netPayable === 500;

      return {
        passed,
        message: passed
          ? 'Payment reversal successfully restored bill status to UNPAID with ₹500 due.'
          : `Mismatch: status=${finalPur?.status}, due=${finalPur?.dueAmount}, netPayable=${summary.netPayable}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 14: Non-Tracked Inventory Purchase
  // ----------------------------------------------------
  await runTest(
    14,
    'Non-Tracked Inventory Purchase (Services / Expense Items)',
    'Inventory Ledger',
    async () => {
      const supplierId = await createTestSupplier('NonTrackSup');
      const itemId = await createTestItem('NonTrackItem', 0, 50, false); // trackInventory = false

      const initialMovements = await db.stockMovements.where('itemId').equals(itemId).count();

      const purchase = await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'NonTrackSup',
        purchaseDate: new Date().toISOString(),
        lines: [
          {
            itemId,
            itemNameSnapshot: 'NonTrackItem',
            quantity: 10,
            unit: 'hrs',
            unitCost: 50,
            discountAmount: 0,
            taxAmount: 0,
            trackInventory: false,
          },
        ],
        subtotal: 500,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 500,
        paidAmount: 500,
        paymentMethod: 'CASH',
      });

      const finalMovements = await db.stockMovements.where('itemId').equals(itemId).count();
      const stock = await inventoryRepository.getItemCurrentStock(itemId);

      const passed =
        purchase.status === 'PAID' &&
        initialMovements === 0 &&
        finalMovements === 0 &&
        stock === 0;

      return {
        passed,
        message: passed
          ? 'Non-tracked purchase generated zero inventory movements while maintaining perfect financial ledger.'
          : `Mismatch: initialMovements=${initialMovements}, finalMovements=${finalMovements}`,
      };
    }
  );

  // ----------------------------------------------------
  // SCENARIO 15: Supplier Statement Ledger Chronology & Running Balance Integrity
  // ----------------------------------------------------
  await runTest(
    15,
    'Supplier Statement Ledger Chronological Running Balance Integrity',
    'Financial Ledger & Statements',
    async () => {
      const supplierId = await createTestSupplier('StatementAuditSup');
      const itemId = await createTestItem('AuditItem', 10, 100);

      // 1. Purchase on Day 1: +₹1,000 payable
      await purchaseService.completePurchase(businessId, {
        supplierId,
        supplierNameSnapshot: 'StatementAuditSup',
        purchaseDate: '2026-01-01T10:00:00Z',
        lines: [{ itemId, itemNameSnapshot: 'AuditItem', quantity: 10, unit: 'pcs', unitCost: 100, discountAmount: 0, taxAmount: 0, trackInventory: true }],
        subtotal: 1000,
        discountAmount: 0,
        taxAmount: 0,
        totalAmount: 1000,
        paidAmount: 0,
        paymentMethod: 'CASH',
      });

      // 2. Payment on Day 2: -₹600 paid -> Balance = ₹400
      const pmt = await supplierPaymentService.recordSupplierPayment({
        businessId,
        supplierId,
        amount: 600,
        paymentMethod: 'BANK_TRANSFER',
        paymentDate: '2026-01-02T10:00:00Z',
        allocationMode: 'AUTO',
      });

      // 3. Reverse Payment on Day 3: +₹600 reversal -> Balance = ₹1,000
      await purchaseCorrectionService.processSupplierPaymentReversal({
        businessId,
        originalPaymentId: pmt.payment.id,
        supplierId,
        reversalDate: '2026-01-03T10:00:00Z',
        reason: 'Bank rejection',
      });

      // 4. Payment on Day 4: -₹1,000 paid -> Balance = ₹0
      await supplierPaymentService.recordSupplierPayment({
        businessId,
        supplierId,
        amount: 1000,
        paymentMethod: 'UPI',
        paymentDate: '2026-01-04T10:00:00Z',
        allocationMode: 'AUTO',
      });

      const statement = await supplierPaymentService.getSupplierStatement(supplierId);
      const summary = await supplierPaymentService.getSupplierFinancialSummary(supplierId);

      const finalEntry = statement[statement.length - 1];
      const has4Entries = statement.length >= 4;
      const isBalanceZero = finalEntry && Math.abs(finalEntry.runningBalance) < 0.005;
      const isSummaryZero = Math.abs(summary.netPayable) < 0.005;

      const passed = has4Entries && isBalanceZero && isSummaryZero;

      return {
        passed,
        message: passed
          ? `Statement computed ${statement.length} chronological entries with exact ending running balance of ₹0.00.`
          : `Mismatch: entriesCount=${statement.length}, finalRunningBalance=${finalEntry?.runningBalance}, summaryNetPayable=${summary.netPayable}`,
        details: statement.map(
          (s) =>
            `${s.date.slice(0, 10)} | ${s.type} | Payable: ₹${s.payable} | Paid: ₹${s.paid} | Balance: ₹${s.runningBalance}`
        ),
      };
    }
  );

  return results;
};
