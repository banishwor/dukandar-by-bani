import { db } from '../db/database';
import { itemRepository } from '../repositories/itemRepository';
import { saleRepository } from '../repositories/saleRepository';
import { purchaseRepository } from '../repositories/purchaseRepository';
import { supplierRepository } from '../repositories/supplierRepository';
import type { DashboardMetrics, ItemWithStock, Sale, Purchase } from '../types';
import { roundCurrency } from '../utils/money';

export const dashboardService = {
  async getDashboardData(businessId: string): Promise<{
    metrics: DashboardMetrics;
    recentSales: Sale[];
    recentPurchases: Purchase[];
    lowStockItems: ItemWithStock[];
  }> {
    const sales = await saleRepository.getSales(businessId);
    const purchases = await purchaseRepository.getPurchases(businessId);
    const items = await itemRepository.getItemsWithStock(businessId);
    const customers = await db.customers
      .where('businessId')
      .equals(businessId)
      .filter((c) => !c.isDeleted)
      .toArray();
    const suppliers = await db.suppliers
      .where('businessId')
      .equals(businessId)
      .filter((s) => !s.isDeleted)
      .toArray();

    // Customer payments & corrections
    const payments = await db.payments
      .where('businessId')
      .equals(businessId)
      .filter((p) => !p.isDeleted)
      .toArray();

    const reversals = await db.paymentReversals
      .where('businessId')
      .equals(businessId)
      .filter((r) => !r.isDeleted)
      .toArray();
    const reversedPaymentIds = new Set(reversals.map((r) => r.originalPaymentId));

    const refunds = await db.refunds
      .where('businessId')
      .equals(businessId)
      .filter((r) => !r.isDeleted)
      .toArray();

    const returns = await db.saleReturns
      .where('businessId')
      .equals(businessId)
      .filter((r) => !r.isDeleted)
      .toArray();

    const totalReturnsAmount = returns.reduce((sum, r) => sum + (Number(r.totalAmount) || 0), 0);
    const totalRefundsAmount = refunds.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);

    const activeSales = sales.filter((s) => s.status !== 'VOIDED');

    const todayStr = new Date().toISOString().slice(0, 10);
    const thisMonthStr = new Date().toISOString().slice(0, 7);

    const todaySales = activeSales.filter(
      (s) => (s.saleDate || s.createdAt).slice(0, 10) === todayStr
    );

    const todaySalesAmount = roundCurrency(
      todaySales.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0)
    );

    const grossSalesAmount = activeSales.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
    const totalSalesAmount = roundCurrency(Math.max(0, grossSalesAmount - totalReturnsAmount));

    const grossPaidAmount = payments
      .filter((p) => !reversedPaymentIds.has(p.id))
      .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const totalPaidAmount = roundCurrency(Math.max(0, grossPaidAmount - totalRefundsAmount));

    const totalDueAmount = roundCurrency(
      activeSales.reduce((sum, s) => sum + (Number(s.dueAmount) || 0), 0)
    );

    // Supplier & Purchases Calculations
    const activePurchases = purchases.filter((p) => p.status !== 'VOIDED');
    const thisMonthPurchases = activePurchases.filter(
      (p) => (p.purchaseDate || p.createdAt).slice(0, 7) === thisMonthStr
    );

    const purchaseReturns = await db.purchaseReturns
      .where('businessId')
      .equals(businessId)
      .filter((r) => !r.isDeleted)
      .toArray();
    const totalPurchaseReturnsAmount = purchaseReturns.reduce((sum, r) => sum + (Number(r.totalAmount) || 0), 0);

    const supplierPayments = await db.supplierPayments
      .where('businessId')
      .equals(businessId)
      .filter((p) => !p.isDeleted)
      .toArray();

    const supplierPaymentReversals = await db.supplierPaymentReversals
      .where('businessId')
      .equals(businessId)
      .filter((r) => !r.isDeleted)
      .toArray();
    const reversedSupplierPaymentIds = new Set(supplierPaymentReversals.map((r) => r.originalPaymentId));

    const refundsReceived = await db.refundsReceived
      .where('businessId')
      .equals(businessId)
      .filter((r) => !r.isDeleted)
      .toArray();
    const totalRefundsReceivedAmount = refundsReceived.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);

    const grossPurchasesAmount = activePurchases.reduce((sum, p) => sum + (Number(p.totalAmount) || 0), 0);
    const totalPurchasesAmount = roundCurrency(Math.max(0, grossPurchasesAmount - totalPurchaseReturnsAmount));

    const grossSupplierPaidAmount = supplierPayments
      .filter((p) => !reversedSupplierPaymentIds.has(p.id))
      .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const totalSupplierPaidAmount = roundCurrency(Math.max(0, grossSupplierPaidAmount - totalRefundsReceivedAmount));

    const totalSupplierDueAmount = roundCurrency(
      activePurchases.reduce((sum, p) => sum + (Number(p.dueAmount) || 0), 0)
    );

    const thisMonthPurchasesAmount = roundCurrency(
      thisMonthPurchases.reduce((sum, p) => sum + (Number(p.totalAmount) || 0), 0)
    );

    const lowStockItems = items.filter((i) => i.isLowStock);

    const metrics: DashboardMetrics = {
      todaySalesCount: todaySales.length,
      todaySalesAmount,
      totalSalesAmount,
      totalPaidAmount,
      totalDueAmount,
      totalCustomersCount: customers.length,
      totalItemsCount: items.length,
      lowStockItemsCount: lowStockItems.length,
      thisMonthPurchasesCount: thisMonthPurchases.length,
      thisMonthPurchasesAmount,
      totalPurchasesAmount,
      totalSupplierPaidAmount,
      totalSupplierDueAmount,
      totalSuppliersCount: suppliers.length,
    };

    return {
      metrics,
      recentSales: sales.slice(0, 6),
      recentPurchases: purchases.slice(0, 6),
      lowStockItems: lowStockItems.slice(0, 5),
    };
  },
};

